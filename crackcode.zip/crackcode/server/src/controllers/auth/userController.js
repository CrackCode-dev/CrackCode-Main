// Legacy controller - re-exports from modular structure
export { getUserData, getUserData as getUserDate } from "../../modules/user/controller.js";
