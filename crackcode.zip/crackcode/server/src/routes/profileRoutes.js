import express from "express";
import { getUserProfile, updateUserProfile } from "../controllers/profileController.js";
import userAuth from "../../../../userprofile/server/middleware/userAuth.js";
import { uploadAvatar } from "../controllers/profileController.js";
import uploadAvatarMulter from "../config/multer.js";
import {
  editEmail,
  changeEmail,
  configureEmailSettings
} from "../controllers/profileController.js";

console.log("profileRoutes loaded");


const router = express.Router();
router.get("/profile", userAuth, getUserProfile);
router.put("/", userAuth, updateUserProfile);

// Upload avatar
router.put(
  "/avatar",
  userAuth,
  uploadAvatarMulter.single("avatar"),
  uploadAvatar
);


// Account settings
router.put("/email/edit", userAuth, editEmail);
router.put("/email/change", userAuth, changeEmail);
router.put("/email/configure", userAuth, configureEmailSettings);

router.get("/test", (req, res) => {
  res.send("profile routes working");
});

router.get("/test", (req, res) => res.send("profile routes working"));


export default router;


