// Legacy route - re-exports from modular structure
export { default } from "../../modules/user/routes.js";
